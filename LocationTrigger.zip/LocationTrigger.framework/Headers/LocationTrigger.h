//
//  LocationTrigger.h
//  LocationTrigger
//
//  Created by Ravikanth on 28/03/18.
//  Copyright © 2018 StoryBoard. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LocationTrigger.
FOUNDATION_EXPORT double LocationTriggerVersionNumber;

//! Project version string for LocationTrigger.
FOUNDATION_EXPORT const unsigned char LocationTriggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LocationTrigger/PublicHeader.h>


